<?php
/**
 * Contact Page - Form for User Messages
 * Student: Mohammad Sulaiman Baber
 * 
 * This page provides a contact form that submits to process_form.php
 * for database storage and cookie tracking
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Me - Mohammad Sulaiman Baber</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <h1 class="header-title">Mohammad Sulaiman Baber</h1>
            <p class="header-subtitle">Software Developer & Web Designer</p>
            <nav class="nav">
                <ul class="nav-list">
                    <li><a href="../index.php#about" class="nav-link">About</a></li>
                    <li><a href="../index.php#experience" class="nav-link">Experience</a></li>
                    <li><a href="../index.php#skills" class="nav-link">Skills</a></li>
                    <li><a href="../index.php#education" class="nav-link">Education</a></li>
                    <li><a href="contact.php" class="nav-link active">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main">
        <section class="section">
            <div class="container">
                <h2 class="section-title">Contact Me</h2>
                <div class="contact-content">
                    <div class="contact-info">
                        <h3>Get in Touch</h3>
                        <p>I'm always interested in new opportunities and collaborations. 
                        Feel free to reach out if you'd like to discuss a project or just say hello!</p>
                        
                        <div class="contact-details">
                            <div class="contact-item">
                                <strong>Email:</strong> mohammad.sulaiman.baber@email.com
                            </div>
                            <div class="contact-item">
                                <strong>Phone:</strong> +1 (555) 123-4567
                            </div>
                            <div class="contact-item">
                                <strong>Location:</strong> New York, NY
                            </div>
                        </div>
                    </div>

                    <div class="contact-form-container">
                        <h3>Send a Message</h3>
                        <form action="../php/process_form.php" method="POST" class="contact-form" id="contactForm">
                            <div class="form-group">
                                <label for="name">Full Name *</label>
                                <input type="text" id="name" name="name" required>
                                <span class="error-message" id="nameError"></span>
                            </div>

                            <div class="form-group">
                                <label for="email">Email Address *</label>
                                <input type="email" id="email" name="email" required>
                                <span class="error-message" id="emailError"></span>
                            </div>

                            <div class="form-group">
                                <label for="subject">Subject *</label>
                                <input type="text" id="subject" name="subject" required>
                                <span class="error-message" id="subjectError"></span>
                            </div>

                            <div class="form-group">
                                <label for="phone">Phone Number (Optional)</label>
                                <input type="tel" id="phone" name="phone">
                                <span class="error-message" id="phoneError"></span>
                            </div>

                            <div class="form-group">
                                <label for="message">Message *</label>
                                <textarea id="message" name="message" rows="6" required></textarea>
                                <span class="error-message" id="messageError"></span>
                            </div>

                            <button type="submit" class="btn btn-primary">Send Message</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 Mohammad Sulaiman Baber. All rights reserved.</p>
        </div>
    </footer>

    <script src="../js/script.js"></script>
</body>
</html>

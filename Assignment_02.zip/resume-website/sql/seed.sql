-- Database Schema and Seed Data
-- Student: Mohammad Sulaiman Baber
-- Assignment 2: PHP + SQL Integration

-- Create database if it doesn't exist
CREATE DATABASE IF NOT EXISTS resume_db;
USE resume_db;

-- Drop tables if they exist (for clean setup)
DROP TABLE IF EXISTS messages;
DROP TABLE IF EXISTS skills;
DROP TABLE IF EXISTS education;

-- Create skills table (simplified for compatibility)
CREATE TABLE skills (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    level VARCHAR(20) NOT NULL
);

-- Create education table
CREATE TABLE education (
    id INT AUTO_INCREMENT PRIMARY KEY,
    institution VARCHAR(150) NOT NULL,
    program_or_role VARCHAR(150) NOT NULL,
    start_year YEAR NOT NULL,
    end_year YEAR NULL,
    description TEXT NULL
);

-- Create messages table for contact form submissions
CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(30) NULL,
    subject VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Insert sample skills data
INSERT INTO skills (name, level) VALUES
('HTML5 & CSS3', 'Advanced'),
('JavaScript (ES6+)', 'Intermediate'),
('React.js', 'Intermediate'),
('PHP', 'Advanced'),
('MySQL', 'Intermediate'),
('Node.js', 'Beginner'),
('Git & GitHub', 'Advanced'),
('Bootstrap', 'Intermediate'),
('MongoDB', 'Beginner'),
('Adobe Creative Suite', 'Intermediate');

-- Insert sample education data
INSERT INTO education (institution, program_or_role, start_year, end_year, description) VALUES
('University of Technology', 'Bachelor of Computer Science', 2015, 2019, 'Graduated with honors. Specialized in Software Engineering and Web Development.'),
('Tech Institute', 'Web Development Certification', 2020, 2020, 'Advanced web development techniques and modern frameworks.'),
('Online Platform', 'React.js Masterclass', 2021, 2021, 'Comprehensive React.js development course with hands-on projects.'),
('Professional Training', 'Database Design & Management', 2022, 2022, 'Advanced database concepts and optimization techniques.');

-- Insert sample messages (optional - for testing)
INSERT INTO messages (full_name, email, subject, message, created_at) VALUES
('John Smith', 'john.smith@email.com', 'Project Inquiry', 'I am interested in discussing a potential web development project. Please contact me.', '2024-01-15 10:30:00'),
('Sarah Johnson', 'sarah.j@company.com', 'Job Opportunity', 'We have an opening for a frontend developer. Would you be interested?', '2024-01-16 14:20:00');

-- Create indexes for better performance
CREATE INDEX idx_skills_level ON skills(level);
CREATE INDEX idx_education_years ON education(start_year, end_year);
CREATE INDEX idx_messages_email ON messages(email);
CREATE INDEX idx_messages_created ON messages(created_at);

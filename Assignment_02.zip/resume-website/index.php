<?php
/**
 * Main Resume Page - Dynamic Content from Database
 * Student: Mohammad Sulaiman Baber
 * 
 * This page dynamically loads skills and education data from the database
 * and displays them in the resume sections
 */

// Include database connection
require_once 'php/db.php';

// Get database connection
$pdo = getDbConnection();

// Initialize variables for data
$skills = [];
$education = [];
$dbError = false;

// Fetch skills from database
if ($pdo) {
    try {
        $skillsStmt = $pdo->query("SELECT name, level FROM skills ORDER BY name");
        $skills = $skillsStmt->fetchAll();
    } catch (PDOException $e) {
        $dbError = true;
        error_log("Error fetching skills: " . $e->getMessage());
    }
    
    // Fetch education from database
    try {
        $educationStmt = $pdo->query("SELECT * FROM education ORDER BY start_year DESC");
        $education = $educationStmt->fetchAll();
    } catch (PDOException $e) {
        $dbError = true;
        error_log("Error fetching education: " . $e->getMessage());
    }
} else {
    $dbError = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mohammad Sulaiman Baber - Professional Resume</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <h1 class="header-title">Mohammad Sulaiman Baber</h1>
            <p class="header-subtitle">Software Developer & Web Designer</p>
            <nav class="nav">
                <ul class="nav-list">
                    <li><a href="#about" class="nav-link">About</a></li>
                    <li><a href="#experience" class="nav-link">Experience</a></li>
                    <li><a href="#skills" class="nav-link">Skills</a></li>
                    <li><a href="#education" class="nav-link">Education</a></li>
                    <li><a href="html/contact.php" class="nav-link">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main">
        <!-- About Section -->
        <section id="about" class="section">
            <div class="container">
                <h2 class="section-title">About Me</h2>
                <div class="about-content">
                    <div class="about-text">
                        <p>I am a passionate software developer with 5+ years of experience in web development, 
                        specializing in front-end technologies and user experience design. I love creating 
                        innovative solutions that solve real-world problems.</p>
                        <p>My expertise includes HTML5, CSS3, JavaScript, PHP, and various modern frameworks. 
                        I am always eager to learn new technologies and take on challenging projects.</p>
                    </div>
                    <div class="about-image">
                        <img src="images/Mohammad Sulaiman Baberjpeg.jpeg" alt="Mohammad Sulaiman Baber" class="profile-img">
                    </div>
                </div>
            </div>
        </section>

        <!-- Experience Section -->
        <section id="experience" class="section">
            <div class="container">
                <h2 class="section-title">Work Experience</h2>
                <div class="experience-grid">
                    <div class="experience-item">
                        <h3 class="job-title">Senior Web Developer</h3>
                        <p class="company">Tech Solutions Inc.</p>
                        <p class="duration">2021 - Present</p>
                        <ul class="job-description">
                            <li>Led development of responsive web applications</li>
                            <li>Mentored junior developers and conducted code reviews</li>
                            <li>Implemented modern UI/UX designs and best practices</li>
                        </ul>
                    </div>
                    <div class="experience-item">
                        <h3 class="job-title">Frontend Developer</h3>
                        <p class="company">Digital Creations Ltd.</p>
                        <p class="duration">2019 - 2021</p>
                        <ul class="job-description">
                            <li>Developed interactive user interfaces using React.js</li>
                            <li>Optimized website performance and accessibility</li>
                            <li>Collaborated with design and backend teams</li>
                        </ul>
                    </div>
                </div>
            </div>
        </section>

        <!-- Skills Section -->
        <section id="skills" class="section">
            <div class="container">
                <h2 class="section-title">Technical Skills</h2>
                <?php if ($dbError || empty($skills)): ?>
                    <!-- Fallback content if database is unavailable -->
                    <div class="skills-grid">
                        <div class="skill-category">
                            <h3>Frontend</h3>
                            <ul class="skill-list">
                                <li>HTML5 & CSS3</li>
                                <li>JavaScript (ES6+)</li>
                                <li>React.js</li>
                                <li>Bootstrap</li>
                            </ul>
                        </div>
                        <div class="skill-category">
                            <h3>Backend</h3>
                            <ul class="skill-list">
                                <li>PHP</li>
                                <li>Node.js</li>
                                <li>MySQL</li>
                                <li>MongoDB</li>
                            </ul>
                        </div>
                        <div class="skill-category">
                            <h3>Tools</h3>
                            <ul class="skill-list">
                                <li>Git & GitHub</li>
                                <li>VS Code</li>
                                <li>Adobe Creative Suite</li>
                                <li>Figma</li>
                            </ul>
                        </div>
                    </div>
                    <?php if ($dbError): ?>
                        <p class="db-notice">Note: Skills are currently displayed from static content. Database connection unavailable.</p>
                    <?php endif; ?>
                <?php else: ?>
                    <!-- Dynamic skills from database -->
                    <div class="skills-grid">
                        <?php
                        // Group skills by level for better organization
                        $skillLevels = ['Expert', 'Advanced', 'Intermediate', 'Beginner'];
                        $groupedSkills = [];
                        
                        foreach ($skills as $skill) {
                            $groupedSkills[$skill['level']][] = $skill['name'];
                        }
                        
                        foreach ($skillLevels as $level) {
                            if (isset($groupedSkills[$level])) {
                                echo '<div class="skill-category">';
                                echo '<h3>' . htmlspecialchars($level) . '</h3>';
                                echo '<ul class="skill-list">';
                                foreach ($groupedSkills[$level] as $skillName) {
                                    echo '<li>' . htmlspecialchars($skillName) . '</li>';
                                }
                                echo '</ul>';
                                echo '</div>';
                            }
                        }
                        ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <!-- Education Section -->
        <section id="education" class="section">
            <div class="container">
                <h2 class="section-title">Education</h2>
                <?php if ($dbError || empty($education)): ?>
                    <!-- Fallback content if database is unavailable -->
                    <div class="education-item">
                        <h3 class="degree">Bachelor of Computer Science</h3>
                        <p class="institution">University of Technology</p>
                        <p class="year">2015 - 2019</p>
                        <p class="description">Graduated with honors. Specialized in Software Engineering and Web Development.</p>
                    </div>
                    <?php if ($dbError): ?>
                        <p class="db-notice">Note: Education is currently displayed from static content. Database connection unavailable.</p>
                    <?php endif; ?>
                <?php else: ?>
                    <!-- Dynamic education from database -->
                    <?php foreach ($education as $edu): ?>
                        <div class="education-item">
                            <h3 class="degree"><?php echo htmlspecialchars($edu['program_or_role']); ?></h3>
                            <p class="institution"><?php echo htmlspecialchars($edu['institution']); ?></p>
                            <p class="year"><?php echo htmlspecialchars($edu['start_year']); ?> - <?php echo $edu['end_year'] ? htmlspecialchars($edu['end_year']) : 'Present'; ?></p>
                            <?php if (!empty($edu['description'])): ?>
                                <p class="description"><?php echo htmlspecialchars($edu['description']); ?></p>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 Mohammad Sulaiman Baber. All rights reserved.</p>
        </div>
    </footer>

    <script src="js/script.js"></script>
</body>
</html>

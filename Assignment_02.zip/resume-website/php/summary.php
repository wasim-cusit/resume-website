<?php
/**
 * Form Submission Summary Page
 * Student: Mohammad Sulaiman Baber
 * 
 * This page displays a summary of the submitted contact form
 * and shows cookie-based message count tracking
 */

// Start session
session_start();

// Include database connection
require_once 'db.php';

// Check if we have a message ID
$messageId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Get message details from database
$message = null;
$dbError = false;

if ($messageId > 0) {
    $pdo = getDbConnection();
    if ($pdo) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM messages WHERE id = ?");
            $stmt->execute([$messageId]);
            $message = $stmt->fetch();
        } catch (PDOException $e) {
            $dbError = true;
            error_log("Error fetching message: " . $e->getMessage());
        }
    } else {
        $dbError = true;
    }
}

// Get cookie-based message count
$cookieCount = 0;
$submittedEmail = $_SESSION['submitted_email'] ?? '';

if (!empty($submittedEmail)) {
    $cookieName = 'message_count_' . md5($submittedEmail);
    $cookieCount = isset($_COOKIE[$cookieName]) ? (int)$_COOKIE[$cookieName] : 0;
}

// Get server-side message count from database
$serverCount = 0;
if (!empty($submittedEmail) && $pdo) {
    try {
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM messages WHERE email = ?");
        $stmt->execute([$submittedEmail]);
        $result = $stmt->fetch();
        $serverCount = $result['count'];
    } catch (PDOException $e) {
        error_log("Error counting messages: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message Submitted - Mohammad Sulaiman Baber</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .summary-container {
            max-width: 800px;
            margin: 2rem auto;
            padding: 2rem;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .success-message {
            background: #d4edda;
            color: #155724;
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 2rem;
            border: 1px solid #c3e6cb;
        }
        
        .message-details {
            background: #f8f9fa;
            padding: 1.5rem;
            border-radius: 5px;
            margin-bottom: 2rem;
        }
        
        .message-details h3 {
            color: #333;
            margin-bottom: 1rem;
        }
        
        .detail-row {
            display: flex;
            margin-bottom: 0.5rem;
            border-bottom: 1px solid #dee2e6;
            padding-bottom: 0.5rem;
        }
        
        .detail-label {
            font-weight: bold;
            width: 120px;
            color: #495057;
        }
        
        .detail-value {
            flex: 1;
            color: #333;
        }
        
        .cookie-banner {
            background: #e7f3ff;
            border: 1px solid #b3d9ff;
            color: #004085;
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 2rem;
        }
        
        .count-display {
            display: flex;
            gap: 2rem;
            margin-top: 1rem;
        }
        
        .count-item {
            background: #fff;
            padding: 1rem;
            border-radius: 5px;
            border: 1px solid #dee2e6;
            text-align: center;
            flex: 1;
        }
        
        .count-number {
            font-size: 2rem;
            font-weight: bold;
            color: #007bff;
        }
        
        .count-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .actions {
            text-align: center;
            margin-top: 2rem;
        }
        
        .btn {
            display: inline-block;
            padding: 0.75rem 1.5rem;
            margin: 0 0.5rem;
            text-decoration: none;
            border-radius: 5px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .btn-primary {
            background: #007bff;
            color: #fff;
        }
        
        .btn-primary:hover {
            background: #0056b3;
        }
        
        .btn-secondary {
            background: #6c757d;
            color: #fff;
        }
        
        .btn-secondary:hover {
            background: #545b62;
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 2rem;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <h1 class="header-title">Mohammad Sulaiman Baber</h1>
            <p class="header-subtitle">Software Developer & Web Designer</p>
            <nav class="nav">
                <ul class="nav-list">
                    <li><a href="../index.php#about" class="nav-link">About</a></li>
                    <li><a href="../index.php#experience" class="nav-link">Experience</a></li>
                    <li><a href="../index.php#skills" class="nav-link">Skills</a></li>
                    <li><a href="../index.php#education" class="nav-link">Education</a></li>
                    <li><a href="../html/contact.php" class="nav-link">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main">
        <div class="container">
            <div class="summary-container">
                <?php if ($dbError): ?>
                    <div class="error-message">
                        <h3>Database Error</h3>
                        <p>Sorry, there was an error retrieving your message details. Please try again later.</p>
                    </div>
                <?php elseif ($message): ?>
                    <div class="success-message">
                        <h3>✅ Message Submitted Successfully!</h3>
                        <p>Thank you for your message. I'll get back to you as soon as possible.</p>
                    </div>

                    <!-- Cookie Count Banner -->
                    <div class="cookie-banner">
                        <h3>📊 Message Tracking</h3>
                        <p>This browser has sent messages from your email address. Here's the count:</p>
                        <div class="count-display">
                            <div class="count-item">
                                <div class="count-number"><?php echo $cookieCount; ?></div>
                                <div class="count-label">Cookie Count<br>(This Browser)</div>
                            </div>
                            <div class="count-item">
                                <div class="count-number"><?php echo $serverCount; ?></div>
                                <div class="count-label">Total Messages<br>(All Time)</div>
                            </div>
                        </div>
                        <p><small>Cookie expires in <?php echo COOKIE_EXPIRY; ?> days</small></p>
                    </div>

                    <!-- Message Details -->
                    <div class="message-details">
                        <h3>Message Details</h3>
                        <div class="detail-row">
                            <div class="detail-label">Name:</div>
                            <div class="detail-value"><?php echo htmlspecialchars($message['full_name']); ?></div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Email:</div>
                            <div class="detail-value"><?php echo htmlspecialchars($message['email']); ?></div>
                        </div>
                        <?php if (!empty($message['phone'])): ?>
                        <div class="detail-row">
                            <div class="detail-label">Phone:</div>
                            <div class="detail-value"><?php echo htmlspecialchars($message['phone']); ?></div>
                        </div>
                        <?php endif; ?>
                        <div class="detail-row">
                            <div class="detail-label">Subject:</div>
                            <div class="detail-value"><?php echo htmlspecialchars($message['subject']); ?></div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Message:</div>
                            <div class="detail-value"><?php echo nl2br(htmlspecialchars($message['message'])); ?></div>
                        </div>
                        <div class="detail-row">
                            <div class="detail-label">Submitted:</div>
                            <div class="detail-value"><?php echo date('F j, Y \a\t g:i A', strtotime($message['created_at'])); ?></div>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="error-message">
                        <h3>Message Not Found</h3>
                        <p>The message you're looking for could not be found or has been removed.</p>
                    </div>
                <?php endif; ?>

                <!-- Action Buttons -->
                <div class="actions">
                    <a href="../html/contact.php" class="btn btn-primary">Send Another Message</a>
                    <a href="../index.php" class="btn btn-secondary">Back to Resume</a>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 Mohammad Sulaiman Baber. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>


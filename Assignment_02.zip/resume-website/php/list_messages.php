<?php
/**
 * Admin Message List Page
 * Student: Mohammad Sulaiman Baber
 * 
 * This page displays all stored contact form messages with pagination
 * and search functionality for administrators
 */

// Start session
session_start();

// Include database connection
require_once 'db.php';

// Pagination settings
$messagesPerPage = 10;
$currentPage = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$offset = ($currentPage - 1) * $messagesPerPage;

// Search functionality
$searchTerm = isset($_GET['search']) ? trim($_GET['search']) : '';
$searchEmail = isset($_GET['email']) ? trim($_GET['email']) : '';

// Get database connection
$pdo = getDbConnection();

// Initialize variables
$messages = [];
$totalMessages = 0;
$totalPages = 0;
$dbError = false;

if ($pdo) {
    try {
        // Build search conditions
        $whereConditions = [];
        $params = [];
        
        if (!empty($searchTerm)) {
            $whereConditions[] = "(full_name LIKE ? OR subject LIKE ? OR message LIKE ?)";
            $searchPattern = "%$searchTerm%";
            $params[] = $searchPattern;
            $params[] = $searchPattern;
            $params[] = $searchPattern;
        }
        
        if (!empty($searchEmail)) {
            $whereConditions[] = "email LIKE ?";
            $params[] = "%$searchEmail%";
        }
        
        $whereClause = !empty($whereConditions) ? 'WHERE ' . implode(' AND ', $whereConditions) : '';
        
        // Get total count for pagination
        $countSql = "SELECT COUNT(*) as total FROM messages $whereClause";
        $countStmt = $pdo->prepare($countSql);
        $countStmt->execute($params);
        $totalMessages = $countStmt->fetch()['total'];
        
        // Calculate total pages
        $totalPages = ceil($totalMessages / $messagesPerPage);
        
        // Ensure current page is within valid range
        if ($currentPage > $totalPages && $totalPages > 0) {
            $currentPage = $totalPages;
            $offset = ($currentPage - 1) * $messagesPerPage;
        }
        
        // Get messages for current page
        $sql = "SELECT * FROM messages $whereClause ORDER BY created_at DESC LIMIT ? OFFSET ?";
        $params[] = $messagesPerPage;
        $params[] = $offset;
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $messages = $stmt->fetchAll();
        
    } catch (PDOException $e) {
        $dbError = true;
        error_log("Database error in list_messages.php: " . $e->getMessage());
    }
} else {
    $dbError = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message List - Admin Panel</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .admin-container {
            max-width: 1200px;
            margin: 2rem auto;
            padding: 2rem;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        
        .admin-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 2rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid #e9ecef;
        }
        
        .admin-title {
            color: #333;
            margin: 0;
        }
        
        .search-form {
            display: flex;
            gap: 1rem;
            align-items: center;
        }
        
        .search-input {
            padding: 0.5rem;
            border: 1px solid #ddd;
            border-radius: 4px;
            min-width: 200px;
        }
        
        .search-btn {
            padding: 0.5rem 1rem;
            background: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .search-btn:hover {
            background: #0056b3;
        }
        
        .clear-btn {
            padding: 0.5rem 1rem;
            background: #6c757d;
            color: #fff;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            display: inline-block;
        }
        
        .clear-btn:hover {
            background: #545b62;
        }
        
        .messages-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 1rem;
        }
        
        .messages-table th,
        .messages-table td {
            padding: 0.75rem;
            text-align: left;
            border-bottom: 1px solid #dee2e6;
        }
        
        .messages-table th {
            background: #f8f9fa;
            font-weight: 600;
            color: #495057;
        }
        
        .messages-table tr:hover {
            background: #f8f9fa;
        }
        
        .message-preview {
            max-width: 200px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
        
        .pagination {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0.5rem;
            margin-top: 2rem;
        }
        
        .pagination a,
        .pagination span {
            padding: 0.5rem 0.75rem;
            text-decoration: none;
            border: 1px solid #dee2e6;
            border-radius: 4px;
            color: #007bff;
        }
        
        .pagination .current {
            background: #007bff;
            color: #fff;
            border-color: #007bff;
        }
        
        .pagination a:hover {
            background: #e9ecef;
        }
        
        .stats {
            background: #f8f9fa;
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .stat-item {
            text-align: center;
        }
        
        .stat-number {
            font-size: 1.5rem;
            font-weight: bold;
            color: #007bff;
        }
        
        .stat-label {
            color: #6c757d;
            font-size: 0.9rem;
        }
        
        .error-message {
            background: #f8d7da;
            color: #721c24;
            padding: 1rem;
            border-radius: 5px;
            margin-bottom: 1rem;
            border: 1px solid #f5c6cb;
        }
        
        .no-messages {
            text-align: center;
            padding: 2rem;
            color: #6c757d;
        }
    </style>
</head>
<body>
    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <h1 class="header-title">Mohammad Sulaiman Baber</h1>
            <p class="header-subtitle">Software Developer & Web Designer</p>
            <nav class="nav">
                <ul class="nav-list">
                    <li><a href="../index.php#about" class="nav-link">About</a></li>
                    <li><a href="../index.php#experience" class="nav-link">Experience</a></li>
                    <li><a href="../index.php#skills" class="nav-link">Skills</a></li>
                    <li><a href="../index.php#education" class="nav-link">Education</a></li>
                    <li><a href="../html/contact.php" class="nav-link">Contact</a></li>
                    <li><a href="list_messages.php" class="nav-link active">Admin</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main">
        <div class="container">
            <div class="admin-container">
                <div class="admin-header">
                    <h2 class="admin-title">📧 Contact Form Messages</h2>
                    <div class="search-form">
                        <input type="text" name="search" placeholder="Search messages..." 
                               value="<?php echo htmlspecialchars($searchTerm); ?>" class="search-input">
                        <input type="email" name="email" placeholder="Filter by email..." 
                               value="<?php echo htmlspecialchars($searchEmail); ?>" class="search-input">
                        <button type="submit" class="search-btn">Search</button>
                        <a href="list_messages.php" class="clear-btn">Clear</a>
                    </div>
                </div>

                <?php if ($dbError): ?>
                    <div class="error-message">
                        <h3>Database Error</h3>
                        <p>Sorry, there was an error connecting to the database. Please check your configuration.</p>
                    </div>
                <?php else: ?>
                    <!-- Statistics -->
                    <div class="stats">
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $totalMessages; ?></div>
                            <div class="stat-label">Total Messages</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $totalPages; ?></div>
                            <div class="stat-label">Total Pages</div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-number"><?php echo $currentPage; ?></div>
                            <div class="stat-label">Current Page</div>
                        </div>
                    </div>

                    <?php if (empty($messages)): ?>
                        <div class="no-messages">
                            <h3>No messages found</h3>
                            <p><?php echo !empty($searchTerm) || !empty($searchEmail) ? 'Try adjusting your search criteria.' : 'No contact form submissions yet.'; ?></p>
                        </div>
                    <?php else: ?>
                        <!-- Messages Table -->
                        <table class="messages-table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Subject</th>
                                    <th>Message Preview</th>
                                    <th>Phone</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($messages as $message): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($message['id']); ?></td>
                                        <td><?php echo htmlspecialchars($message['full_name']); ?></td>
                                        <td><?php echo htmlspecialchars($message['email']); ?></td>
                                        <td><?php echo htmlspecialchars($message['subject']); ?></td>
                                        <td class="message-preview" title="<?php echo htmlspecialchars($message['message']); ?>">
                                            <?php echo htmlspecialchars(substr($message['message'], 0, 50)) . (strlen($message['message']) > 50 ? '...' : ''); ?>
                                        </td>
                                        <td><?php echo !empty($message['phone']) ? htmlspecialchars($message['phone']) : '-'; ?></td>
                                        <td><?php echo date('M j, Y g:i A', strtotime($message['created_at'])); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>

                        <!-- Pagination -->
                        <?php if ($totalPages > 1): ?>
                            <div class="pagination">
                                <?php if ($currentPage > 1): ?>
                                    <a href="?page=<?php echo $currentPage - 1; ?>&search=<?php echo urlencode($searchTerm); ?>&email=<?php echo urlencode($searchEmail); ?>">← Previous</a>
                                <?php endif; ?>
                                
                                <?php for ($i = max(1, $currentPage - 2); $i <= min($totalPages, $currentPage + 2); $i++): ?>
                                    <?php if ($i == $currentPage): ?>
                                        <span class="current"><?php echo $i; ?></span>
                                    <?php else: ?>
                                        <a href="?page=<?php echo $i; ?>&search=<?php echo urlencode($searchTerm); ?>&email=<?php echo urlencode($searchEmail); ?>"><?php echo $i; ?></a>
                                    <?php endif; ?>
                                <?php endfor; ?>
                                
                                <?php if ($currentPage < $totalPages): ?>
                                    <a href="?page=<?php echo $currentPage + 1; ?>&search=<?php echo urlencode($searchTerm); ?>&email=<?php echo urlencode($searchEmail); ?>">Next →</a>
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>

                <!-- Action Buttons -->
                <div style="text-align: center; margin-top: 2rem;">
                    <a href="../index.php" class="btn btn-secondary">Back to Resume</a>
                    <a href="../html/contact.php" class="btn btn-primary">Send Message</a>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 Mohammad Sulaiman Baber. All rights reserved.</p>
        </div>
    </footer>

    <script>
        // Simple search form handling
        document.addEventListener('DOMContentLoaded', function() {
            const searchInputs = document.querySelectorAll('.search-input');
            const searchBtn = document.querySelector('.search-btn');
            
            searchBtn.addEventListener('click', function() {
                const searchTerm = document.querySelector('input[name="search"]').value;
                const searchEmail = document.querySelector('input[name="email"]').value;
                
                let url = 'list_messages.php?';
                if (searchTerm) url += 'search=' + encodeURIComponent(searchTerm) + '&';
                if (searchEmail) url += 'email=' + encodeURIComponent(searchEmail) + '&';
                
                // Remove trailing & and redirect
                url = url.replace(/&$/, '');
                window.location.href = url;
            });
            
            // Allow Enter key to submit search
            searchInputs.forEach(input => {
                input.addEventListener('keypress', function(e) {
                    if (e.key === 'Enter') {
                        searchBtn.click();
                    }
                });
            });
        });
    </script>
</body>
</html>

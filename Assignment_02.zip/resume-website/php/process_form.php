<?php
/**
 * Contact Form Processing Script
 * Student: Mohammad Sulaiman Baber
 * 
 * This script handles form validation, database insertion, and cookie tracking
 * for contact form submissions
 */

// Start session for error handling
session_start();

// Include database connection
require_once 'db.php';

// Include configuration
require_once __DIR__ . '/../config/config.sample.php';

// Initialize variables
$errors = [];
$formData = [];

// Check if form was submitted
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../html/contact.php');
    exit();
}

// Get and sanitize form data
$formData['full_name'] = isset($_POST['name']) ? trim($_POST['name']) : '';
$formData['email'] = isset($_POST['email']) ? trim($_POST['email']) : '';
$formData['phone'] = isset($_POST['phone']) ? trim($_POST['phone']) : '';
$formData['subject'] = isset($_POST['subject']) ? trim($_POST['subject']) : '';
$formData['message'] = isset($_POST['message']) ? trim($_POST['message']) : '';

// Server-side validation
if (empty($formData['full_name'])) {
    $errors['name'] = 'Full name is required';
} elseif (strlen($formData['full_name']) > 120) {
    $errors['name'] = 'Full name must be less than 120 characters';
}

if (empty($formData['email'])) {
    $errors['email'] = 'Email address is required';
} elseif (!filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) {
    $errors['email'] = 'Please enter a valid email address';
} elseif (strlen($formData['email']) > 150) {
    $errors['email'] = 'Email address must be less than 150 characters';
}

if (empty($formData['subject'])) {
    $errors['subject'] = 'Subject is required';
} elseif (strlen($formData['subject']) > 150) {
    $errors['subject'] = 'Subject must be less than 150 characters';
}

if (empty($formData['message'])) {
    $errors['message'] = 'Message is required';
} elseif (strlen($formData['message']) > 10000) {
    $errors['message'] = 'Message must be less than 10,000 characters';
}

// Phone validation (optional field)
if (!empty($formData['phone']) && strlen($formData['phone']) > 30) {
    $errors['phone'] = 'Phone number must be less than 30 characters';
}

// If there are validation errors, redirect back with errors
if (!empty($errors)) {
    $_SESSION['form_errors'] = $errors;
    $_SESSION['form_data'] = $formData;
    header('Location: ../html/contact.php');
    exit();
}

// Get database connection
$pdo = getDbConnection();

if (!$pdo) {
    $_SESSION['form_errors'] = ['general' => 'Database connection failed. Please try again later.'];
    $_SESSION['form_data'] = $formData;
    header('Location: ../html/contact.php');
    exit();
}

try {
    // Prepare SQL statement for inserting message
    $sql = "INSERT INTO messages (full_name, email, phone, subject, message) VALUES (?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    
    // Execute with sanitized data
    $stmt->execute([
        htmlspecialchars($formData['full_name']),
        htmlspecialchars($formData['email']),
        htmlspecialchars($formData['phone']),
        htmlspecialchars($formData['subject']),
        htmlspecialchars($formData['message'])
    ]);
    
    // Get the inserted message ID
    $messageId = $pdo->lastInsertId();
    
    // Handle cookie tracking for message count
    $cookieName = COOKIE_NAME . '_' . md5($formData['email']);
    $currentCount = isset($_COOKIE[$cookieName]) ? (int)$_COOKIE[$cookieName] : 0;
    $newCount = $currentCount + 1;
    
    // Set cookie for 30 days
    $expiry = time() + (COOKIE_EXPIRY * 24 * 60 * 60);
    setcookie($cookieName, $newCount, $expiry, '/');
    
    // Store message count in session for summary page
    $_SESSION['message_count'] = $newCount;
    $_SESSION['submitted_email'] = $formData['email'];
    
    // Redirect to summary page
    header('Location: summary.php?id=' . $messageId);
    exit();
    
} catch (PDOException $e) {
    // Log error
    error_log("Database error in process_form.php: " . $e->getMessage());
    
    // Set error message
    $_SESSION['form_errors'] = ['general' => 'An error occurred while saving your message. Please try again.'];
    $_SESSION['form_data'] = $formData;
    
    // Redirect back to contact form
    header('Location: ../html/contact.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Processing - Mohammad Sulaiman Baber</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>
    <!-- Header Section -->
    <header class="header">
        <div class="container">
            <h1 class="header-title">Mohammad Sulaiman Baber</h1>
            <p class="header-subtitle">Software Developer & Web Designer</p>
            <nav class="nav">
                <ul class="nav-list">
                    <li><a href="../index.html#about" class="nav-link">About</a></li>
                    <li><a href="../index.html#experience" class="nav-link">Experience</a></li>
                    <li><a href="../index.html#skills" class="nav-link">Skills</a></li>
                    <li><a href="../index.html#education" class="nav-link">Education</a></li>
                    <li><a href="../html/contact.html" class="nav-link">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main">
        <section class="section">
            <div class="container">
                <h2 class="section-title">Form Processing</h2>
                
                <?php if (!empty($errors)): ?>
                    <div class="error-container">
                        <h3>Please correct the following errors:</h3>
                        <ul class="error-list">
                            <?php foreach ($errors as $field => $error): ?>
                                <li><strong><?php echo ucfirst($field); ?>:</strong> <?php echo $error; ?></li>
                            <?php endforeach; ?>
                        </ul>
                        <div class="error-actions">
                            <a href="../html/contact.html" class="btn btn-primary">Back to Contact Form</a>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <p>&copy; 2024 Mohammad Sulaiman Baber. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>

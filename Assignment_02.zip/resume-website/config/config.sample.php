<?php
/**
 * Database Configuration Template
 * Student: Mohammad Sulaiman Baber
 * 
 * Copy this file to config.php and fill in your actual database credentials
 */

// Database configuration
define('DB_HOST', 'localhost');     // Your database host (usually localhost for XAMPP)
define('DB_NAME', 'resume_db');     // Your database name
define('DB_USER', 'root'); // Your database username (usually 'root' for XAMPP)
define('DB_PASS', ''); // Your database password (usually empty for XAMPP)

// Database charset
define('DB_CHARSET', 'utf8mb4');

// Cookie settings
define('COOKIE_EXPIRY', 30); // Days
define('COOKIE_NAME', 'message_count');
?>

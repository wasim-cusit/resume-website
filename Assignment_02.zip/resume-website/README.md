# Resume Website - PHP + SQL Integration

**Student:** Mohammad Sulaiman Baber  
**Assignment:** Assignment 2 - PHP + SQL Integration (Dynamic Content & Message Storage)

## 🚀 Quick Setup Guide

### Prerequisites
- XAMPP, MAMP, or similar local development environment
- PHP 7.4+ with PDO MySQL extension
- MySQL 5.7+ or MariaDB 10.2+
- Web browser

## 📋 Setup Steps

### Step 1: Start Your Local Server
1. **Open XAMPP Control Panel**
2. **Start Apache** (click "Start")
3. **Start MySQL** (click "Start")
4. **Ensure both services show green status**

### Step 2: Database Setup
1. **Open phpMyAdmin** in your browser: `http://localhost/phpmyadmin`
2. **Create new database:**
   ```sql
   CREATE DATABASE resume_db;
   ```
3. **Select the database:**
   ```sql
   USE resume_db;
   ```

### Step 3: Import Database Schema
**Option A: Import SQL File**
- In phpMyAdmin, select `resume_db` database
- Click "Import" tab
- Choose `sql/seed.sql` file
- Click "Go" to import

**Option B: Manual Table Creation**
```sql
-- Create skills table
CREATE TABLE skills (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    level VARCHAR(20) NOT NULL
);

-- Create education table
CREATE TABLE education (
    id INT AUTO_INCREMENT PRIMARY KEY,
    institution VARCHAR(150) NOT NULL,
    program_or_role VARCHAR(150) NOT NULL,
    start_year YEAR NOT NULL,
    end_year YEAR NULL,
    description TEXT NULL
);

-- Create messages table
CREATE TABLE messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(30) NULL,
    subject VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

### Step 4: Insert Sample Data
```sql
-- Insert sample skills
INSERT INTO skills (name, level) VALUES
('HTML5 & CSS3', 'Advanced'),
('JavaScript (ES6+)', 'Intermediate'),
('React.js', 'Intermediate'),
('PHP', 'Advanced'),
('MySQL', 'Intermediate'),
('Node.js', 'Beginner'),
('Git & GitHub', 'Advanced'),
('Bootstrap', 'Intermediate'),
('MongoDB', 'Beginner'),
('Adobe Creative Suite', 'Intermediate');

-- Insert sample education
INSERT INTO education (institution, program_or_role, start_year, end_year, description) VALUES
('University of Technology', 'Bachelor of Computer Science', 2015, 2019, 'Graduated with honors. Specialized in Software Engineering and Web Development.'),
('Tech Institute', 'Web Development Certification', 2020, 2020, 'Advanced web development techniques and modern frameworks.'),
('Online Platform', 'React.js Masterclass', 2021, 2021, 'Comprehensive React.js development course with hands-on projects.'),
('Professional Training', 'Database Design & Management', 2022, 2022, 'Advanced database concepts and optimization techniques.');
```

### Step 5: Access Your Website
1. **Navigate to your project folder in browser:**
   ```
   http://localhost/City_Collage_Students/resume-website/
   ```
2. **Or directly to main page:**
   ```
   http://localhost/City_Collage_Students/resume-website/index.php
   ```

## 🗂️ Project Structure

```
resume-website/
├── index.php                    # Main resume page (dynamic from DB)
├── html/
│   └── contact.php             # Contact form
├── php/
│   ├── process_form.php        # Form validation & database insertion
│   ├── summary.php             # Submission summary with cookie tracking
│   ├── list_messages.php       # Admin message viewing
│   └── db.php                  # PDO database connection
├── config/
│   └── config.sample.php       # Database configuration (used directly)
├── sql/
│   └── seed.sql                # Database schema & sample data
├── includes/
│   └── header.html             # Reusable header component
├── css/
│   └── style.css               # All styling
├── js/
│   └── script.js               # JavaScript functionality
└── images/
    └── Mohammad Sulaiman Baberjpeg.jpeg  # Profile image
```

## 🧪 Testing Your Setup

### Test 1: Main Resume Page
- **URL:** `index.php`
- **Expected:** Skills and education loaded from database
- **Fallback:** Static content if database unavailable

### Test 2: Contact Form
- **URL:** `html/contact.php`
- **Action:** Fill out and submit form
- **Result:** Redirect to summary page with cookie tracking

### Test 3: Admin Panel
- **URL:** `php/list_messages.php`
- **Features:** Message list, search, pagination, statistics

## 🔧 Troubleshooting

### Common Issues & Solutions

#### Database Connection Failed
- **Check:** MySQL service is running in XAMPP
- **Verify:** Database `resume_db` exists
- **Confirm:** Username is `root` and password is empty

#### Skills/Education Not Loading
- **Check:** Database tables exist and have data
- **Verify:** Run `SELECT * FROM skills;` in phpMyAdmin
- **Confirm:** Database connection in `config.sample.php`

#### Form Not Submitting
- **Check:** All required fields are filled
- **Verify:** Database table structure matches schema
- **Confirm:** PHP has write permissions

#### Tablespace Errors
- **Solution:** Drop database completely and recreate
- **Alternative:** Delete database folder manually and restart MySQL

### Error Logs Location
- **XAMPP:** `xampp/apache/logs/error.log`
- **MAMP:** `MAMP/logs/apache_error.log`

## 📊 Database Schema

### Tables Overview
1. **`skills`** - Technical skills with proficiency levels
2. **`education`** - Educational background and certifications  
3. **`messages`** - Contact form submissions

### Sample Data Included
- **Skills:** 10 skills across different proficiency levels
- **Education:** 4 education entries with descriptions
- **Messages:** 2 sample contact form submissions

## 🍪 Cookie System

### How It Works
- **Purpose:** Track message count per email per browser
- **Expiration:** 30 days from creation
- **Privacy:** Email addresses are hashed in cookie names
- **Display:** Shows both cookie count and server-side total

## 🛡️ Security Features

- **Input Validation:** Server-side validation of all inputs
- **SQL Injection Prevention:** Prepared statements for all queries
- **XSS Prevention:** Output escaping with `htmlspecialchars()`
- **Input Sanitization:** Comprehensive validation and sanitization
- **Error Handling:** Graceful fallbacks and user-friendly messages

## 🌐 Browser Compatibility

- Chrome 80+
- Firefox 75+
- Safari 13+
- Edge 80+

## 📱 Responsive Design

- Mobile-first approach
- Works on all device sizes
- Modern CSS Grid and Flexbox
- Smooth animations and transitions

## 🚀 Features Implemented

✅ **Dynamic Content:** Skills and education from database  
✅ **Database Storage:** Contact form submissions stored in MySQL  
✅ **Cookie Tracking:** Message count per email per browser  
✅ **Admin Panel:** View all submissions with search and pagination  
✅ **Form Validation:** Client-side and server-side validation  
✅ **Security:** XSS prevention, SQL injection protection  
✅ **Responsive Design:** Works on all devices  
✅ **Error Handling:** Graceful fallbacks and user feedback  

## 🔍 Quick Database Commands

```sql
-- Check database exists
SHOW DATABASES;

-- Use database
USE resume_db;

-- Show all tables
SHOW TABLES;

-- Check table structure
DESCRIBE skills;
DESCRIBE education;
DESCRIBE messages;

-- View sample data
SELECT * FROM skills;
SELECT * FROM education;
SELECT * FROM messages;

-- Count records
SELECT COUNT(*) FROM skills;
SELECT COUNT(*) FROM education;
SELECT COUNT(*) FROM messages;
```

## 📞 Support

If you encounter issues:
1. **Check error logs** in your server directory
2. **Verify database connection** in phpMyAdmin
3. **Ensure all files** are in correct locations
4. **Check file permissions** are set correctly

## 📄 License

This project is created for educational purposes as part of Assignment 2.

---

**Happy Coding! 🎉**
